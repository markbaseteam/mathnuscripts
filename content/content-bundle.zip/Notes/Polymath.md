# Polymath

This is my cup of team, literally. I want people who can shift from one concept to the next with high flexibility. People who can have a discussion on geopolitics, religion, science, philosophy and so on. People who can get lost in a stream of thought is a blessing to me. 

I am not passionate about people but I love this segment of people and I want more of them in my life. These are the polymaths

Refer to [[Cerebrations]]

