# Naval's Important Skills To Have

1. Reading
2. Writing
3. Speaking
4. Arithmetic
5. Programming