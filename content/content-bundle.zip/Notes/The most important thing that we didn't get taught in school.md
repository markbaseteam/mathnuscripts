# The Most Important Thing to Learn in School

Building great things people want to use. That's the article. Bye!