# A Study of Decadence

In this video, [Link](https://www.youtube.com/watch?v=wKBMRkFIdm0), he talks about decadence and how a society becomes reflective and not passionate. It doesn't seek to act but philosophize or shelter itself from pain and suffereing. It is always thinking and not doing things.

A society starts being decadent when it stops looking at the stars and drowns itself in wine. 

Refer to [[Finding Passion in a Passionless Age]]
