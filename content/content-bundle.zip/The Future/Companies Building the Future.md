# Companies Building the Future

In this list, you will find the companies that I believe are charting a new path for humanity in terms of technology and innovation. I will add more as I go along.

1. [[SpaceX]]
2. [[DeepMind]]
3. [[Boston Dynamics]]
4. [[DWave]]
5. [[Tesla]]
6. [[Neuralink]]
7. [[Makani]] - a worthy attempt
8. [[Mighty Browser]]
9. [[SpinLaunch]]
10. [[OpenAI]]