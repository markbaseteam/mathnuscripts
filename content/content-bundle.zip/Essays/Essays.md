# Essays Written

1. [[The Product Journey]]
2. [[My Living Manuscript]]
3. [[Working should be fun]]
4. [[My Recap of 1 Year at IAN]]
5. [[The Appeal of Personal Blogs]]
6. [[Why Share My Writing]]
7. [[Thoughts on Web3 and How to Fix it]]
8. [[How I Got Started with Blockchain]]
9. [[Product Development Frameworks]]
10. [[Building the Future]]
11. [[Incurable Itch]]
12. [[Note-taker's Dilemma]]
13. [[Produce a Lot of Shitty Work]]

