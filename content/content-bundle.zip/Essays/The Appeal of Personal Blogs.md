# The Appeal of a Personal Blog

There is more to a personal blog than just sharing your thoughts with people in text format. Writing serves a purpose, not just to the reader but for the writer as well. To write is to think and thinking leads to learning.

My obsession with personal blogs has been growing since I started journalling in early 2020. Once I got one year into the habit, I thought it would be great to start my own blog. With all the supposedly great thoughts I was having, I thought it would be great to share them and get some validation of them. "I would have been a great dopamine boost", I thought.

Fast-forward and here I am on this journey of writing on my first personal blog. But why personal? There are many websites like Medium or Substack that are great for blogging. They have great templates, amazing fonts, no writing code and even algorithms to recommend your articles to other people. It seems like no-brainer to get started on those. 

My view is that a personal blog offers to much more, it's simply personal. I will break this concept down using multiple points:

## 1. Limited by interests, not topics or niches
Conventional blogging advice suggests that you must find a niche topic to write about for a specific target audience. You start by picking a topic area like woodworking. From there, you assess whether there are people who would like to learn about woodworking. You segment them into various groups such as beginners, intermediate or advanced. You select what you region you will focus on like East Africa or Europe. Once you have gone through this process, you have a niche and you can start writing blogs for beginner woodworkers in East Africa. Now you have a blog.

To a number of people this is fine if they want to become creators and make a living. It will also work for someone with a carpentry business and is looking to absorb talent or offer training. But what about people who just want to share their thoughts online.

People have more than one interest. They can be finance analyst by profession but do some woodwork as a hobby on the weekend. They could be software developers by love to keep dogs. By following conventional blogging wisdom, such people with dual-interests who have to start a blog for each interest. There lies the problem, no one wants to manage to two blogs, especially at the beginning of their writing hobby.

Personal blogs offer an excuse to have multiple interests. Why? Well, it's about you after all. It is expected that your blog will have a wide range of topics. People don't come to learn a new skill but to read your opinions on a topic they are interested in. They are looking for their tribe of like-minded people. By having a personal blog, you are connecting to people on an interest-level, not a topical-level. If they connect on one of your interests like woodworking, they may be interested to learn about your work in finance. (Could be a poor analogy by bare with me)

It also stems that by writing about your interests, you realise your niche in the process. You realise that other people are just like you. They like the same weird things and have the same weird thoughts. 

## 2. Writing is thinking
I have two questions for you:
- How do you get to know something if you have never thought about it? 
- How can you understand what you have thought about without writing it down?

By writing your thoughts down, you take your blurring ideas and pass them through the narrow pipe of words. In doing so, you get what is truly essential by synthesising the murky thoughts and turning them into a stream of characters that can be understood by other human beings. For as long as we have no telepathy, no one can understand your thoughts.

What makes writing more powerful than speaking is that it makes you think more closely about your thoughts. Speaking is quite natural from an evolutionary perspective, making it is easy to stream your thoughts. Simply put, it is a wider pipe that allows murky ideas to flow through. You can mumble through your speech and not notice. On the other hand, writing requires more processing power to pull off. You have to think about the words to use, their spelling, the hand coordination and so on. That makes ideas harder to put down but it ensures that what is put down is essential.

By essential, I mean what is murky and not what is ready for publishing. Editing is requires for any first draft that you make. At the end of the day, some murk always passed through. The only thing you can do for your writing is making it less murky.

Through this process, you refine the construction of your ideas and how they connect together. By writing, you notice blindspots in your grammar, thought process, biases and later, your interests. I like this quote that summarises the point on interests:

> “Of all the books I have delivered to the presses, none, I think, is as personal as the straggling collection mustered for this hodgepodge, precisely because it abounds in reflections and interpolations. Few things have happened to me, and I have read a great many. Or rather, few things have happened to me more worth remembering than Schopenhauer’s thought or the music of England’s words.
> 
> A man sets himself the task of portraying the world. Through the years he peoples a space with images of provinces, kingdoms, mountains, bays, ships, islands, fishes, rooms, instruments, stars, horses, and people. Shortly before his death, he discovers that that patient labyrinth of lines traces the image of his face.”
\ - [Jorge Luis Borges](https://en.wikipedia.org/wiki/Jorge_Luis_Borges "Jorge Luis Borges")⁠, _[Dreamtigers](https://en.wikipedia.org/wiki/Dreamtigers "Dreamtigers")_ [⁠Epilogue](https://www.gwern.net/docs/www/thefloatinglibrary.com/8de9abd7b5a4a796dadc4416ea8e7285a1d6c751.html "(Original URL: https://thefloatinglibrary.com/2008/12/09/dreamtigers-epiloge-j-l-borges/ )")

## 3. Own digital real estate
In my country, Kenya, we love buying land. It is always on our checklist of things to own. There are the usual reasons to own land:
1. It always "appreciates" in value
2. To be closer to our roots by owning land in our ancestral area
3. To own an asset that can be passed down to our children
4. To build a retirement home
5. To setup rental apartments

The list can go on but those are the ones that come my mind.

Kenyans dwell on the owning a part of the physical world and I can say same for any other culture. People have fought over land since the days that hunters and gatherers decided to settle down and farm. We want to hold our claim on this world and make it in our own image.

As the digital revolution came about, the internet was born and it opened up a new world, the world of bits. Unlike the world of atoms, the world of bits is limitless. The concept of the Turing machine (horribly summarised) can process and display anything imaginable. Playing on the information theory, which could be a base of a our physical world (Simulation Theory and a story for another day). In short, we can build a whole new world with no limits that can express our humanity and what we represent. 

Blogs are just one way of doing that but there are so many others like social media platforms, publication sites, tubesites like YouTube and so on. However, personal blogs are a form that allows the user to own their data and display in the form that they want. Platforms such as YouTube or Medium have a cookie-cutter style for each user's page. There is not enough room to express eccentricity apart from changing your display photo, cover photo and theme colours.

No one wants a cookie-cutter home, especially if they want to leave in it for a long time. Our home are an expression of ourselves. Each item from a painting on the wall to the TV brand that you have. All are an expression of our values and what we believe in. Our homes in the real world are an expression of ourselves. Why not do the same for your digital home? Why keep paying rent for the rest of the digital life? Own a piece of the digital realm. It is going to be here for a while so make yourself comfortable.

## Rough Notes
* Personal writing stands the test of time. Look at Leonardo Da Vinci Manuscripts, The Dead Sea Scrolls, the Tales of Gilgamesh
	* Looking closer, we have the blogs of Paul Graham, Chris Dixon
* Personal blogs are not limited by a topic but by the interests of the individual in question
* Writing is thinking through what you really enjoy
* Like real estate, you get to own a piece of the internet, not rent it
	* Paying for a domain is like land rates
	* The internet is going nowhere so why not solidify your stay
* Personal blogs are open to more diversity in look, feel and function. Adds character
* Back to the vision of the original internet. Decentralised, wild and free
* The articles are not just for you, they are for those who come after you
	* Your writing is a mentor
- Personal blogs are more human and encompass who we are, more than what we do