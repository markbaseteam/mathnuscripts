# MathnuScripts

Welcome to the Mathnuscripts, the tip of the iceberg of the Digital Mind project.

## Introduction
This is a long-term project to collect the ideas, thoughts and knowledge that I have and nurture them into a comprehensive, navigable and understandable body of knowledge that can be browsed, analysed and presented to others and myself.

The goal is to have this knowledge base as the beginning of something bigger than myself. Something that I will leave behind and benefit other people.

## Getting Started
Here are some subjects and notes you can get started on: 
1. Product: [[Product Development Frameworks]]
2. Startups: [[The Product Journey]]
3. Philosophy: [[Gnosticism]], [[Incurable Itch]]
4. Personal Stories: [[My Recap of 1 Year at IAN]], [[How I Got Started with Blockchain]]
5. Technology: [[Living in the Software Age]], [[HTTP]]
6. Innovation: [[5-step process of rigorous implementation]]
7. Digital Gardening: [[My Living Manuscript]]
8. Writing: [[The Appeal of Personal Blogs]], [[Why Share My Writing]]
9. Mindset: [[Winning makes things easier]], [[Working should be fun]]

## How to Use
You can navigate using the links and folders to find more interesting notes and essays on a wide array of subjects. I use [Obsidian](https://obsidian.md/) to make these notes happen and I host them using [Markbase](https://www.markbase.xyz/Home).

This is the Journal: The Making of a Digital Mind

Enjoy!

Kind regards,
Mathenge Waweru.